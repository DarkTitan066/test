This assignment is my Event Center Website Project. 
This assignment is my take on a restaurant's website. The restaurant holds all rights to the information provided in this project.
Index.html is my home page that greets visitors and helps them find what they are looking for.
Location.html is the page that shows the location of the restaurant and what hours they are open.
Contact.html is my contact page where people can leave comments and reach out to ask any more detailed questions.
Events.html is my events page where it shows visitors what events are happening soon and what they can join in on.
Menu.html is my menu page that shows the different food items available that the restaurant has to offer.
Styles.css contains the CSS rules that define the visual presentation of the website.